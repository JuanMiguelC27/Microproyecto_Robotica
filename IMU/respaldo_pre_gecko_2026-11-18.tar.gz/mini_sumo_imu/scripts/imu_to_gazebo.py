#!/usr/bin/env python3
"""IMU calibration + mounting-axis correction + Gazebo pose synchronization.

ROS 2 Humble / Gazebo Fortress.
Input:  sensor_msgs/msg/Imu on /imu/data
Output: TF world -> Base_link and Gazebo SetEntityPose service calls.

Mount parameters describe the fixed transform Base_link -> imu_link (RPY degrees).
The incoming IMU quaternion is assumed to follow ROS REP-145 conventions.
"""

import math
from typing import Optional, Tuple

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from geometry_msgs.msg import TransformStamped
from sensor_msgs.msg import Imu
from std_srvs.srv import Trigger
from tf2_ros import TransformBroadcaster, StaticTransformBroadcaster
from ros_gz_interfaces.srv import SetEntityPose

Quaternion = Tuple[float, float, float, float]  # ROS order: x, y, z, w


def q_normalize(q: Quaternion) -> Quaternion:
    n = math.sqrt(sum(v * v for v in q))
    if not math.isfinite(n) or n < 1e-12:
        raise ValueError('Invalid or near-zero quaternion')
    return tuple(v / n for v in q)  # type: ignore[return-value]


def q_conjugate(q: Quaternion) -> Quaternion:
    return (-q[0], -q[1], -q[2], q[3])


def q_multiply(a: Quaternion, b: Quaternion) -> Quaternion:
    """Hamilton product a*b in ROS xyzw order."""
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return (
        aw*bx + ax*bw + ay*bz - az*by,
        aw*by - ax*bz + ay*bw + az*bx,
        aw*bz + ax*by - ay*bx + az*bw,
        aw*bw - ax*bx - ay*by - az*bz,
    )


def q_from_rpy(roll: float, pitch: float, yaw: float) -> Quaternion:
    cr, sr = math.cos(roll/2), math.sin(roll/2)
    cp, sp = math.cos(pitch/2), math.sin(pitch/2)
    cy, sy = math.cos(yaw/2), math.sin(yaw/2)
    return q_normalize((
        sr*cp*cy - cr*sp*sy,
        cr*sp*cy + sr*cp*sy,
        cr*cp*sy - sr*sp*cy,
        cr*cp*cy + sr*sp*sy,
    ))


class ImuToGazebo(Node):
    def __init__(self):
        super().__init__('imu_to_gazebo')

        # Topics, names and frames.
        defaults = {
            'imu_topic': '/imu/data',
            'service_name': '/world/empty/set_pose',
            'entity_name': 'mini_sumo',
            'entity_id': 0,
            'entity_type': 2,  # Gazebo MODEL
            'world_frame': 'world',
            'base_frame': 'Base_link',
            'imu_frame': 'imu_link',
            'x': 0.0, 'y': 0.0, 'z': 0.000004376,
            # Fixed orientation of imu_link relative to Base_link.
            'imu_mount_roll_deg': 0.0,
            'imu_mount_pitch_deg': 0.0,
            'imu_mount_yaw_deg': 0.0,
            # IMU origin relative to Base_link, metres.
            'imu_offset_x': 0.0, 'imu_offset_y': 0.0, 'imu_offset_z': 0.0,
            'auto_calibrate': True,
            'calibration_service': '/imu/calibrate',
            'update_rate_hz': 20.0,
        }
        for name, value in defaults.items():
            self.declare_parameter(name, value)

        p = lambda name: self.get_parameter(name).value
        self.imu_topic = str(p('imu_topic'))
        self.service_name = str(p('service_name'))
        self.entity_name = str(p('entity_name'))
        self.entity_id = int(p('entity_id'))
        self.entity_type = int(p('entity_type'))
        self.world_frame = str(p('world_frame'))
        self.base_frame = str(p('base_frame'))
        self.imu_frame = str(p('imu_frame'))
        self.calibration_service_name = str(p('calibration_service'))
        self.auto_calibrate = bool(p('auto_calibrate'))
        self.position = (float(p('x')), float(p('y')), float(p('z')))
        self.imu_offset = (
            float(p('imu_offset_x')), float(p('imu_offset_y')),
            float(p('imu_offset_z')),
        )

        mount_rpy_deg = (
            float(p('imu_mount_roll_deg')),
            float(p('imu_mount_pitch_deg')),
            float(p('imu_mount_yaw_deg')),
        )
        mount_rpy = tuple(math.radians(v) for v in mount_rpy_deg)
        # q_base_imu is the static orientation Base_link -> imu_link.
        self.q_base_imu = q_from_rpy(*mount_rpy)

        rate = float(p('update_rate_hz'))
        if not math.isfinite(rate) or rate <= 0:
            raise ValueError('update_rate_hz must be positive and finite')

        self.latest_q_world_imu: Optional[Quaternion] = None
        self.q_reference_world_base: Optional[Quaternion] = None
        self.request_in_flight = False
        self.warned_service_unavailable = False

        self.tf_broadcaster = TransformBroadcaster(self)
        self.tf_static_broadcaster = StaticTransformBroadcaster(self)
        self.client = self.create_client(SetEntityPose, self.service_name)
        self.subscription = self.create_subscription(
            Imu, self.imu_topic, self.imu_callback, qos_profile_sensor_data
        )
        self.calibration_service = self.create_service(
            Trigger, self.calibration_service_name, self.calibrate_callback
        )
        self.timer = self.create_timer(1.0/rate, self.update_gazebo_and_tf)
        self.publish_static_imu_transform()

        self.get_logger().info(f'Listening to IMU: {self.imu_topic}')
        self.get_logger().info(f'Gazebo service: {self.service_name}')
        self.get_logger().info(
            f'Model={self.entity_name}; TF={self.world_frame} -> {self.base_frame}'
        )
        self.get_logger().info(
            f'IMU mount RPY Base_link -> imu_link (deg): {mount_rpy_deg}'
        )
        self.get_logger().info(
            f'Calibration service: {self.calibration_service_name}'
        )
        if self.auto_calibrate:
            self.get_logger().info(
                'Auto-calibration: first valid IMU message becomes the zero reference.'
            )
        else:
            self.get_logger().warning(
                'Automatic calibration disabled; call /imu/calibrate after IMU data arrives.'
            )

    def publish_static_imu_transform(self):
        """Publish the fixed Base_link -> imu_link mounting transform on /tf_static."""
        t = TransformStamped()
        t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = self.base_frame
        t.child_frame_id = self.imu_frame
        t.transform.translation.x, t.transform.translation.y, t.transform.translation.z = self.imu_offset
        t.transform.rotation.x, t.transform.rotation.y = self.q_base_imu[0:2]
        t.transform.rotation.z, t.transform.rotation.w = self.q_base_imu[2:4]
        self.tf_static_broadcaster.sendTransform(t)

    def sensor_to_base(self, q_world_imu: Quaternion) -> Quaternion:
        """q_world_base = q_world_imu * inverse(q_base_imu)."""
        return q_normalize(q_multiply(q_world_imu, q_conjugate(self.q_base_imu)))

    def imu_callback(self, msg: Imu):
        # REP-145 uses orientation_covariance[0] = -1 when orientation is unavailable.
        if msg.orientation_covariance[0] == -1.0:
            self.get_logger().warning('IMU orientation is marked unavailable; sample ignored.')
            return
        q = msg.orientation
        try:
            self.latest_q_world_imu = q_normalize((float(q.x), float(q.y), float(q.z), float(q.w)))
        except ValueError:
            self.get_logger().warning('Invalid/near-zero IMU quaternion; sample ignored.')
            return

        if self.q_reference_world_base is None and self.auto_calibrate:
            self.q_reference_world_base = self.sensor_to_base(self.latest_q_world_imu)
            self.get_logger().info(
                'Calibration captured: current physical pose is now 0 degrees in Gazebo.'
            )

    def calibrate_callback(self, request: Trigger.Request,
                           response: Trigger.Response) -> Trigger.Response:
        del request
        if self.latest_q_world_imu is None:
            response.success = False
            response.message = 'No valid IMU sample received yet; cannot calibrate.'
            return response
        self.q_reference_world_base = self.sensor_to_base(self.latest_q_world_imu)
        response.success = True
        response.message = 'Calibration updated; current physical orientation is now zero.'
        self.get_logger().info(response.message)
        return response

    def update_gazebo_and_tf(self):
        if self.latest_q_world_imu is None or self.q_reference_world_base is None:
            return

        q_world_base = self.sensor_to_base(self.latest_q_world_imu)
        # Relative orientation in the initial Base_link coordinate frame.
        q_relative = q_normalize(q_multiply(
            q_conjugate(self.q_reference_world_base), q_world_base
        ))
        qx, qy, qz, qw = q_relative
        stamp = self.get_clock().now().to_msg()

        # Dynamic TF: world -> Base_link.
        tf_msg = TransformStamped()
        tf_msg.header.stamp = stamp
        tf_msg.header.frame_id = self.world_frame
        tf_msg.child_frame_id = self.base_frame
        tf_msg.transform.translation.x, tf_msg.transform.translation.y, tf_msg.transform.translation.z = self.position
        tf_msg.transform.rotation.x = qx
        tf_msg.transform.rotation.y = qy
        tf_msg.transform.rotation.z = qz
        tf_msg.transform.rotation.w = qw
        self.tf_broadcaster.sendTransform(tf_msg)

        if self.request_in_flight:
            return
        if not self.client.service_is_ready():
            if not self.warned_service_unavailable:
                self.get_logger().warning(
                    f'Waiting for {self.service_name}; check ros_gz_bridge.'
                )
                self.warned_service_unavailable = True
            return
        self.warned_service_unavailable = False

        req = SetEntityPose.Request()
        req.entity.id = self.entity_id
        req.entity.name = self.entity_name
        req.entity.type = self.entity_type
        req.pose.position.x, req.pose.position.y, req.pose.position.z = self.position
        req.pose.orientation.x = qx
        req.pose.orientation.y = qy
        req.pose.orientation.z = qz
        req.pose.orientation.w = qw

        self.request_in_flight = True
        future = self.client.call_async(req)
        future.add_done_callback(self.service_done_callback)

    def service_done_callback(self, future):
        self.request_in_flight = False
        try:
            if not future.result().success:
                self.get_logger().error(f'Gazebo rejected pose update for {self.entity_name}.')
        except Exception as exc:
            self.get_logger().error(f'Gazebo SetEntityPose call failed: {exc}')


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = ImuToGazebo()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
