
#!/usr/bin/env bash
# Inicia hotspot, un mundo Gazebo Fortress NUEVO (empty.sdf),
# el robot, el puente ROS-Gazebo y los nodos del sistema Mini Sumo.
#
# Uso:
# ./start_mini_sumo_pc.sh
# ./start_mini_sumo_pc.sh stop

set -Eeuo pipefail

# --------------------------- CONFIGURACIÓN ---------------------------

WIFI_IFACE="${WIFI_IFACE:-wlo1}"
HOTSPOT_SSID="${HOTSPOT_SSID:-MiniSumo-IMU}"
HOTSPOT_PASSWORD="${HOTSPOT_PASSWORD:-MiniSumo2026!}"
HOTSPOT_IP="${HOTSPOT_IP:-10.42.0.1/24}"

PROJECT_DIR="${PROJECT_DIR:-$HOME/Documentos/Noveno_Semestre/Robotica/Microproyecto/IMU/mini_sumo_imu}"

SCRIPTS_DIR="$PROJECT_DIR/scripts"
WALL_SDF="$PROJECT_DIR/models/wall/wall.sdf"

ROBOT_URDF="${ROBOT_URDF:-$HOME/Documentos/Noveno_Semestre/Robotica/Macroproyecto/Personal/mini_sumoV3_URDF/urdf/mini_sumoV3_gazebo.urdf}"

ROS_SETUP="/opt/ros/humble/setup.bash"

WORLD_NAME="empty"
ROBOT_NAME="mini_sumo"
WALL_NAME="mini_sumo_wall"

STATE_DIR="$HOME/.local/state/mini_sumo_imu"
LOG_DIR="$STATE_DIR/logs"
PID_DIR="$STATE_DIR/pids"


# ------------------------------ UTILIDADES ---------------------------

info() {
    printf '\n[PC] %s\n' "$*"
}

fail() {
    printf '\n[PC][ERROR] %s\n' "$*" >&2
    exit 1
}

require_command() {
    command -v "$1" >/dev/null 2>&1 ||
        fail "No se encontró el comando '$1'."
}


# Iniciar un proceso en segundo plano y registrar su PID.
start_bg() {

    local name="$1"
    shift

    local pidfile="$PID_DIR/$name.pid"
    local logfile="$LOG_DIR/$name.log"

    if [[ -f "$pidfile" ]]; then

        local old_pid
        old_pid="$(cat "$pidfile" 2>/dev/null || true)"

        if [[ -n "$old_pid" ]] &&
           kill -0 "$old_pid" 2>/dev/null; then

            info "$name ya está ejecutándose (PID $old_pid)."
            return 0
        fi

        rm -f "$pidfile"
    fi

    nohup "$@" >>"$logfile" 2>&1 </dev/null &

    local new_pid=$!
    printf '%s\n' "$new_pid" > "$pidfile"

    sleep 1

    if ! kill -0 "$new_pid" 2>/dev/null; then

        rm -f "$pidfile"

        printf '\n--- Últimas líneas de %s ---\n' "$logfile" >&2
        tail -n 40 "$logfile" >&2 || true

        fail "No se pudo iniciar $name."
    fi

    info "$name iniciado (PID $new_pid)."
    info "Registro: $logfile"
}


# Esperar a que Gazebo publique un servicio.
wait_for_ign_service() {

    local service="$1"
    local attempts="${2:-60}"

    for ((i=1; i<=attempts; i++)); do

        if ign service -l 2>/dev/null | grep -Fq "$service"; then
            return 0
        fi

        sleep 1
    done

    return 1
}


# Eliminar una entidad del mundo Gazebo.
remove_entity_if_present() {

    local name="$1"

    ign service -s "/world/$WORLD_NAME/remove" \
        --reqtype ignition.msgs.Entity \
        --reptype ignition.msgs.Boolean \
        --timeout 3000 \
        --req "name: \"$name\", type: 2" \
        >/dev/null 2>&1 || true
}


# Cerrar TODAS las instancias anteriores de Gazebo.
stop_gazebo_processes() {

    if pgrep -f '[i]gn gazebo' >/dev/null 2>&1; then

        info "Cerrando las instancias anteriores de Gazebo..."

        pkill -TERM -f '[i]gn gazebo' 2>/dev/null || true

        for _ in {1..10}; do

            if ! pgrep -f '[i]gn gazebo' >/dev/null 2>&1; then
                break
            fi

            sleep 1
        done

        if pgrep -f '[i]gn gazebo' >/dev/null 2>&1; then

            info "Finalizando los procesos de Gazebo restantes..."

            pkill -KILL -f '[i]gn gazebo' 2>/dev/null || true

            sleep 1
        fi
    fi

    rm -f "$PID_DIR/gazebo.pid"
    rm -f "$PID_DIR/gazebo_gui.pid"
}


# ------------------------------ DETENER ------------------------------

stop_all() {

    info "Deteniendo el sistema Mini Sumo..."

    local name
    local pidfile
    local pid

    for name in wall_manager estimator orientation receiver bridge; do

        pidfile="$PID_DIR/$name.pid"

        if [[ -f "$pidfile" ]]; then

            pid="$(cat "$pidfile" 2>/dev/null || true)"

            if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
                kill "$pid" 2>/dev/null || true
            fi

            rm -f "$pidfile"
        fi
    done

    # Eliminar entidades antes de cerrar Gazebo.
    if command -v ign >/dev/null 2>&1 &&
       wait_for_ign_service "/world/$WORLD_NAME/remove" 3; then

        remove_entity_if_present "$WALL_NAME"
        remove_entity_if_present "$ROBOT_NAME"
    fi

    # Cerrar servidor e interfaz gráfica.
    stop_gazebo_processes

    # Apagar hotspot.
    if command -v nmcli >/dev/null 2>&1; then
        nmcli connection down "$HOTSPOT_SSID" >/dev/null 2>&1 || true
    fi

    info "Sistema detenido y hotspot desactivado."
}


# ------------------------------- INICIO ------------------------------

main() {

    mkdir -p "$LOG_DIR" "$PID_DIR"

    case "${1:-start}" in
        stop)
            stop_all
            exit 0
            ;;
        start)
            ;;
        *)
            fail "Uso: $0 [start|stop]"
            ;;
    esac


    # Comprobar comandos y archivos.
    for cmd in nmcli ign python3 ping ip tail pgrep pkill; do
        require_command "$cmd"
    done

    [[ -f "$ROS_SETUP" ]] ||
        fail "No existe $ROS_SETUP"

    [[ -f "$ROBOT_URDF" ]] ||
        fail "No existe el URDF del robot: $ROBOT_URDF"

    [[ -f "$SCRIPTS_DIR/udp_imu_receiver.py" ]] ||
        fail "Falta udp_imu_receiver.py"

    [[ -f "$SCRIPTS_DIR/imu_to_gazebo.py" ]] ||
        fail "Falta imu_to_gazebo.py"

    [[ -f "$SCRIPTS_DIR/imu_displacement_estimator.py" ]] ||
        fail "Falta imu_displacement_estimator.py"

    [[ -f "$SCRIPTS_DIR/wall_climb_manager.py" ]] ||
        fail "Falta wall_climb_manager.py"

    [[ -f "$WALL_SDF" ]] ||
        fail "No existe el modelo de pared: $WALL_SDF"


    # Cargar ROS 2 Humble.
    # Desactivar nounset temporalmente para evitar errores de setup.bash.

    set +u
    source "$ROS_SETUP"
    set -u

    require_command ros2


    # Eliminar nodos anteriores para evitar procesos duplicados.

    pkill -f '[i]mu_odom_to_gazebo.py' 2>/dev/null || true
    pkill -f '[i]mu_to_gazebo.py' 2>/dev/null || true
    pkill -f '[u]dp_imu_receiver.py' 2>/dev/null || true
    pkill -f '[i]mu_displacement_estimator.py' 2>/dev/null || true
    pkill -f '[w]all_climb_manager.py' 2>/dev/null || true
    pkill -f '[p]arameter_bridge /world/empty' 2>/dev/null || true

    sleep 1


    # ================================================================
    # 1. ACTIVAR HOTSPOT
    # ================================================================

    info "Configurando hotspot Wi-Fi $HOTSPOT_SSID..."

    nmcli radio wifi on

    if ! nmcli -t -f NAME connection show |
         grep -Fxq "$HOTSPOT_SSID"; then

        nmcli connection add type wifi \
            ifname "$WIFI_IFACE" \
            con-name "$HOTSPOT_SSID" \
            ssid "$HOTSPOT_SSID" >/dev/null
    fi

    nmcli connection modify "$HOTSPOT_SSID" \
        connection.autoconnect no \
        802-11-wireless.mode ap \
        802-11-wireless.band bg \
        wifi-sec.key-mgmt wpa-psk \
        wifi-sec.psk "$HOTSPOT_PASSWORD" \
        ipv4.method shared \
        ipv4.addresses "$HOTSPOT_IP" \
        ipv6.method ignore

    nmcli connection up "$HOTSPOT_SSID" >/dev/null

    local ip_ok=0

    for _ in {1..15}; do

        if ip -4 addr show dev "$WIFI_IFACE" 2>/dev/null |
           grep -Fq "${HOTSPOT_IP%/*}"; then

            ip_ok=1
            break
        fi

        sleep 1
    done

    [[ "$ip_ok" -eq 1 ]] ||
        fail "El hotspot no obtuvo la IP ${HOTSPOT_IP%/*}."

    info "Hotspot activo. IP: ${HOTSPOT_IP%/*}"


    # ================================================================
    # 2. CREAR SIEMPRE UN GAZEBO NUEVO
    # ================================================================

    info "Cerrando cualquier instancia anterior de Gazebo..."

    stop_gazebo_processes

    sleep 2

    # Reiniciar registro de Gazebo.
    : > "$LOG_DIR/gazebo.log"

    info "Iniciando un mundo nuevo con empty.sdf..."

    # -r inicia la simulación sin pausa y abre la interfaz gráfica.
    start_bg gazebo ign gazebo -r empty.sdf

    info "Esperando los servicios del nuevo mundo..."

    wait_for_ign_service "/world/$WORLD_NAME/create" 60 ||
        fail "Gazebo no publicó el servicio create."

    wait_for_ign_service "/world/$WORLD_NAME/remove" 20 ||
        fail "Gazebo no publicó el servicio remove."

    info "Mundo empty creado correctamente."


    # ================================================================
    # 3. INSERTAR ROBOT
    # ================================================================

    info "Insertando el modelo $ROBOT_NAME..."

    local create_result

    create_result=$(
    ign service \
        -s "/world/$WORLD_NAME/create" \
        --reqtype ignition.msgs.EntityFactory \
        --reptype ignition.msgs.Boolean \
        --timeout 10000 \
        --req "sdf_filename: \"$ROBOT_URDF\", name: \"$ROBOT_NAME\""
    ) || fail "No se pudo insertar el robot."

    printf '%s\n' "$create_result"

    grep -q 'data: true' <<<"$create_result" ||
    fail "Gazebo no confirmó la creación del robot."

    sleep 2


    # ================================================================
    # 4. PUENTE ROS 2 - GAZEBO
    # ================================================================

    info "Iniciando puente ROS 2 - Gazebo..."

    start_bg bridge ros2 run ros_gz_bridge parameter_bridge \
        "/world/$WORLD_NAME/set_pose@ros_gz_interfaces/srv/SetEntityPose" \
        "/world/$WORLD_NAME/create@ros_gz_interfaces/srv/SpawnEntity" \
        "/world/$WORLD_NAME/remove@ros_gz_interfaces/srv/DeleteEntity"

    local service_ok=0

    for _ in {1..30}; do

        if ros2 service list 2>/dev/null |
           grep -Fxq "/world/$WORLD_NAME/set_pose"; then

            service_ok=1
            break
        fi

        sleep 1
    done

    [[ "$service_ok" -eq 1 ]] ||
        fail "El puente no publicó /world/$WORLD_NAME/set_pose."


    # ================================================================
    # 5. RECEPTOR UDP
    # ================================================================

    info "Iniciando receptor UDP..."

    start_bg receiver python3 \
        "$SCRIPTS_DIR/udp_imu_receiver.py"


    # ================================================================
    # 6. ORIENTACIÓN DEL ROBOT
    # ================================================================

    info "Iniciando control de orientación a 30 Hz..."

    # Solo orientación. No se aplica desplazamiento estimado.

    start_bg orientation python3 \
        "$SCRIPTS_DIR/imu_to_gazebo.py" \
        --ros-args -p update_rate_hz:=30.0


    # ================================================================
    # 7. ESTIMADOR DE PITCH
    # ================================================================

    # Se conserva únicamente porque el gestor de pared consume
    # /imu/estimated_pitch_deg.
    #
    # La posición calculada NO se aplica al robot en Gazebo.

    info "Iniciando estimador de Pitch..."

    start_bg estimator python3 \
        "$SCRIPTS_DIR/imu_displacement_estimator.py"


    # ================================================================
    # 8. GESTOR DE PARED
    # ================================================================

    info "Iniciando gestor de pared..."

    start_bg wall_manager python3 \
        "$SCRIPTS_DIR/wall_climb_manager.py"


    # ================================================================
    # 9. RESUMEN
    # ================================================================

    info "Sistema Mini Sumo iniciado correctamente."

    printf '\n'
    printf '  Hotspot:         %s\n' "$HOTSPOT_SSID"
    printf '  IP del PC:       %s\n' "${HOTSPOT_IP%/*}"
    printf '  Mundo:           empty.sdf NUEVO\n'
    printf '  Robot:           %s\n' "$ROBOT_NAME"
    printf '  IMU:             UDP 5005 -> /imu/data\n'
    printf '  Orientación:     30 Hz solicitados\n'
    printf '  Pared:           wall_climb_manager.py\n'
    printf '  Desplazamiento:  DESACTIVADO\n'
    printf '\n'
    printf '  Registros: %s\n' "$LOG_DIR"
    printf '  Detener:   %s stop\n' "$0"
}

main "$@"

